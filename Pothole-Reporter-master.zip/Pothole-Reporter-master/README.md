# Pothole Reporter App

An app built on Flutter, to help citizens report potholes to civic authorities.

## The work completed so far
  - User Login, Signup
  - Capturing image using camera

This project is a starting point for a Flutter application.
